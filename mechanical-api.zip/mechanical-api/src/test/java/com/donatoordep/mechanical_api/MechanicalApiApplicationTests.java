package com.donatoordep.mechanical_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MechanicalApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
