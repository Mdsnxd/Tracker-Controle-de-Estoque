package com.donatoordep.mechanical_api.builders;

public interface Builder<E> {

    E build();
}