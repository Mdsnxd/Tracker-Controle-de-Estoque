package com.donatoordep.mechanical_api.repositories.impl;

import com.donatoordep.mechanical_api.repositories.ItemRepositorySpecification;

public interface ItemRepositoryImpl extends ItemRepositorySpecification {
}