package com.donatoordep.mechanical_api.exceptions.base;

public interface ONBExceptionSpecification {
    Integer getStatus();

    String getError();
}
