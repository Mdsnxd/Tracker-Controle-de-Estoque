package com.donatoordep.mechanical_api.services.validations.user.register;

public interface UserRegisterValidation {
    void validate(UserRegisterArgs args);
}